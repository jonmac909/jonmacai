# Multi-Model Cost Routing Cheat Sheet (AI Income Lab)

Stop paying flagship Opus/frontier rates for every single task. Route jobs by strength & cost:

| Job Type | Best Primary Model | Backup / Escalation | Why It Saves ~65% |
|---|---|---|---|
| **3D / Interactive Explainers & Motion Graphics** | **Gemini 4 Neon** | Claude Opus (polish) | 2.4× faster & 64% cheaper in Jon's blind 5-job test ($7.58 vs $21.25 total) |
| **Pure-Code Tools, SVGs & Dashboards** | **Gemini 4 Neon** | Codex / Claude | Fast single-shot visual & math output at a fraction of token cost |
| **Brand Copy, Homepages & Nuanced Editorial** | **Claude Opus / Sonnet** | Gemini 4 Neon | Edge on character, copy voice, and subtle layout judgment |
| **Bulk Scraping, Extraction & File Triage** | **Flash / Mini / Cheap Tier** | Gemini 4 Neon | pennies per million tokens; zero reason to burn Opus quota |
| **Multi-Step Production Debugging** | **Claude Code / Codex** | Gemini 4 Neon | Strong surgical multi-file diffs when strict tests exist |

## The 3-Step Cost Cut Checklist
1. Drop `CLAUDE.md` into every project root today.
2. Separate heavy visual/code prototyping onto **Gemini 4 Neon** (or cheap high-throughput models) and reserve flagship Claude for architecture, copy voice, and final review.
3. Track real wall time + token spend on 1 real client job this week — most operators cut monthly AI spend by 50–65% immediately.
