# Token-Saver Workspace Rules (Drop Into Your Project Root as CLAUDE.md or AGENTS.md)

## Token & Context Discipline (Cuts AI Burn ~60–65%)
- Run multi-step checks and builds as ONE filtered script or chained command that prints only counts, paths, failures, and compact tables — never run 10 separate tool calls dumping raw output into context.
- Never dump whole files, long logs, raw JSON, or full HTML into context; search, grep, tail, or write to a file and inspect only the needed slice.
- For browser work, batch known click/type/extract sequences into ONE script returning only the needed values instead of taking a full DOM snapshot after every click.
- Inspect video/design frames ONLY as ONE JPEG contact sheet (4x4 max, 1024 px wide) — never read individual full-size PNG frames one by one.
- Run independent reads, searches, and edits together in parallel in a single turn.
- Keep project context crisp in 4 small markdown files (`business.md`, `brand-voice.md`, `icp.md`, `offer.md`) so the model stops guessing or breaking unrelated code.

## Voice-Only Video Standard
- Clean, crisp voice-only output for all client and channel videos (zero distracting background music beds or SFX clutter).
