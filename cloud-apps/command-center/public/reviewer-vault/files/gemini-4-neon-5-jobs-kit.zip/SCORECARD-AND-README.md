# Gemini 4 Neon vs. Claude Opus — 5 Real Jobs Prompt Pack & Cost Scorecard
**From:** Jon Mac (`AI Income Lab` — `https://www.skool.com/jonmac`)  
**Benchmark Video:** `I Tested Gemini 4 Neon on 5 Real Jobs. It's Scary Good (and Cheap)` (`https://youtu.be/TlZK_qF2qCI`)  
**Run Method:** Blind one-shot tests using the exact same prompt word-for-word (`prompts/t1.txt`–`t5.txt`). Zero follow-ups, zero reruns.

---

## Head-to-Head Results Scorecard

| # | Real Business Job | Winner | Gemini 4 Neon Time | Gemini 4 Neon Cost | Claude Opus Time | Claude Opus Cost | Cost Savings |
|---:|---|---|---:|---:|---:|---:|---:|
| 1 | 3D wind turbine explainer | **Gemini 4 Neon** | 10.1 min | $1.71 | 34.9 min | $6.85 | **75% cheaper** |
| 2 | 15 s motion graphic about the word SPARK | **Gemini 4 Neon** | 8.7 min | $1.31 | 14.0 min | $2.70 | **51% cheaper** |
| 3 | Tally homepage | **Claude Opus** | 6.5 min | $1.02 | 16.0 min | $2.22 | **54% cheaper** |
| 4 | HyperFrames edit of Jon's 30 s clip | **Gemini 4 Neon** | 11.6 min | $1.72 | 12.2 min | $3.08 | **44% cheaper** |
| 5 | Pure-code mechanical music box | **Tie (Neon faster/cheaper)** | 12.2 min | $1.82 | 40.0 min | $6.40 | **72% cheaper** |
| **TOTAL** | **All 5 Real Jobs (Score: 3–1–1 Neon)** | **Gemini 4 Neon** | **49.1 min** | **$7.58** | **117.1 min** | **$21.25** | **64.3% cheaper (2.4× faster)** |

---

## How To Run Your Own Blind Model Test
1. Pick one real business output you already build (landing page, motion explainer, video edit, code tool).
2. Drop the exact prompt from `prompts/t1.txt`–`t5.txt` into both models in separate clean folders — one shot, zero coaching.
3. Track wall time, token usage, and real API cost, and judge the finished artifact BEFORE looking at which model built it.
